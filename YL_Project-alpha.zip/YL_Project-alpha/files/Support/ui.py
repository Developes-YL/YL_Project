# различные константы для окон

from pygame import image


BACK = image.load('images/back.png')

fs = image.load('images/fs.png')  # надо бы переименовать названия в CAPS
kir = image.load('images/kir.png')
beton = image.load('images/beton.png')
forest = image.load('images/forest.png')
base = image.load('images/base.png')
dbase = image.load('images/dbase.png')
water = image.load('images/water.png')
ggu = image.load('images/ggu.png')
e = image.load('images/e.png')
