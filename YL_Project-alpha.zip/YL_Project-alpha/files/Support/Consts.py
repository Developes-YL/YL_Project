# главные константы приложения и механик игры

WINDOW_SIZE = (0, 0)
FPS = 60
TITLE = "TANK 1990"

FILES = []
LIBRARIES = []
