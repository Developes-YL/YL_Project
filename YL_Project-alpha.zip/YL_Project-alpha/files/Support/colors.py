import pygame

WHITE = pygame.Color("WHITE")
BLACK = pygame.Color("BLACK")
RED = pygame.Color("RED")
BLUE = pygame.Color("BLUE")
GREEN = pygame.Color("GREEN")
COLOR_2 = pygame.Color((255, 0, 153))  # надо бы переименовать
